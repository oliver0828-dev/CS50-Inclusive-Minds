import SwiftUI

struct SchoolView: View {
    @State var icons: [Icon] = iconList.icon
    
    var body: some View {
        NavigationStack{
            Spacer()
            VStack{
                List(icons.indices, id: \.self){ index in
                    let icon = icons[index]
                    NavigationLink(destination: icon.viewName){
                        SchoolBoxView(textColor: Color.primary, boxColor: icon.boxColor, image: icon.imageName, imageName: icon.titleName, imageColor: icon.imageColor)
                    }
                    
                    
                    
                }
            }
            
        }
        
        
        
    }
}
