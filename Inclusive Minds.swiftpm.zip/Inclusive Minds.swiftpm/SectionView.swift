import SwiftUI

struct SectionView: View {
    let spacing: CGFloat
    let horizontalPadding: CGFloat
    @Binding var selectedSection: Int?
    
    var body: some View {
        GeometryReader { geometry in
            let cardWidth = (geometry.size.width - (horizontalPadding * 2) - (spacing * 2)) / 3
            HStack(spacing: spacing) {
                ForEach(0..<3) { index in
                    SectionCardView(
                        title: self.title(for: index),
                        description: self.description(for: index),
                        imageName: "SectionCard\(index + 1)"
                    )
                    .frame(width: cardWidth, height: cardWidth)
                    .onTapGesture {
                        self.selectedSection = index
                    }
                }
            }
            .padding(.horizontal, horizontalPadding)
            .frame(height: cardWidth)
        }
        .frame(height: (UIScreen.main.bounds.width - (horizontalPadding * 2) - (spacing * 2)) / 3)
    }
    

    private func title(for index: Int) -> String {
        switch index {
        case 0:
            return "Understanding and Addressing Racism in the Classroom"
        case 1:
            return "Promoting Diversity and Inclusivity"
        case 2:
            return "Final Quiz in Racism"
        default:
            return "Unknown"
        }
    }
    
    
    private func description(for index: Int) -> String {
        switch index {
        case 0:
            return "How Can We Racism in School?"
        case 1:
            return "How Can We Promote Diversity and Inclusivity?"
        case 2:
            return "How Can We Foster Inclusion and Respect? "
        default:
            return "Unknown description"
        }
    }
}

struct SectionCardView: View {
    var title: String
    var description: String
    var imageName: String
    var body: some View {
        ZStack(alignment: .topLeading) {
            Rectangle()
                .foregroundStyle(Color.yellow.gradient)
                .scaledToFill()
                .frame(width: 250, height: 250)
                .clipped()
                .opacity(0.3)
                .cornerRadius(15)
            
            VStack(alignment: .leading, spacing: 8) {
                Text(title)
                    .font(.title)
                    .fontWeight(.bold)
                    .foregroundColor(.black)
                    .padding([.top, .horizontal], 10)
                
                Text(description)
                    .font(.subheadline)
                    .foregroundColor(.black)
                    .padding(.horizontal, 10)
            }
        }
        .frame(width: 250, height: 250)
        .background(RoundedRectangle(cornerRadius: 15).fill(Color.white))
        .overlay(
            RoundedRectangle(cornerRadius: 15)
                .stroke(Color.black, lineWidth: 2)
        )
    }
}


