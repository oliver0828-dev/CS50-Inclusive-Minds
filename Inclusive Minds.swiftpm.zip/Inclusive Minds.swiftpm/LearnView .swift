import SwiftUI

struct LearnView: View {
    @State var cards: [Card] = cardList.card
    
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack {
                    LearnCardView(cards: cards)
                    SchoolView().frame(height: 1000)
                }
            }
            .navigationTitle("Learn")
        }
    }
}
