import SwiftUI

struct QuizView: View {
    let spacing: CGFloat = 15
    let horizontalPadding: CGFloat = 20
    @State private var selectedSection: Int? = nil

    var body: some View {
        ZStack {
            Color.orange.edgesIgnoringSafeArea(.all)

            VStack {
                if selectedSection == nil {
                    BadgeView()
                    
                    SectionView(spacing: spacing, horizontalPadding: horizontalPadding, selectedSection: $selectedSection)
                        .padding(.leading, horizontalPadding)
                    
                } else if let selectedSection = selectedSection {
                    QuizContentsView(sectionID: selectedSection, selectedSection: $selectedSection)
                }

                Spacer()
            }
        }
    }
}

